def developer1Method():
    print('My name: Aizhamal')
    print('My surname: Zhetigenova')
    print('My email: 7genowa@gmail.com')
    print('My cohort: CS 2025')
    print('My age: 20')
    print('My gender: Female')
    print('My birthdate: 14 January, 2002')
    print("My speciality: Computer Science")
    print("My country: Kyrgyzstan")


def developer2Method():
    print("name: marzia")
    print("last name: jafari")
    print("conutry: Afg")
    print("My speciality: Computer Science")
    print('My birthdate: 17 may, 1999')
    print("cohort: 2")
    print("age: 23")
    print("cohort")
    print("email: marzia.jafari32@gmail.com")



def developer3Method():
    print("First name: Baistan")
    print("Last name: Tashkulov")
    print("email: baistan.xi@gmail.com")
    print("cohort: Computer Science")
    print("age: 19")
    print("gender: male")
    print("birthdate: June 27, 2002")
    print("speciality: Software engineer")
    print("country : Kg")


    # method calling
developer1Method()
developer2Method()
developer3Method()
