# Intro2CS-final-exam

## Group "J"

### Members

> Baistan Tashkulov (developer3, feat3 | Lead)
>
> Aizhamal Zhetigenova (developer1, feature1)
>
> Marzia Taban Jafari (developer2, feature2 )
